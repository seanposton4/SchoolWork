// Output created by jacc on Fri Oct 09 21:37:44 CDT 2020

interface LooplangTokens {
    int ENDINPUT = 0;
    int ARRAY = 1;
    int ASSIGN = 2;
    int DIVIDE = 3;
    int END = 4;
    int EQ = 5;
    int EXP = 6;
    int GE = 7;
    int GT = 8;
    int ID = 9;
    int IN = 10;
    int LBRACKET = 11;
    int LE = 12;
    int LITERAL = 13;
    int LPAREN = 14;
    int LT = 15;
    int MINUS = 16;
    int MULTIPLY = 17;
    int OUT = 18;
    int PLUS = 19;
    int RBRACKET = 20;
    int RPAREN = 21;
    int WHILE = 22;
    int error = 23;
}
