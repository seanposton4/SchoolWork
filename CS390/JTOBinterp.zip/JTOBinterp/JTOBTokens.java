// Output created by jacc on Mon Nov 23 00:29:07 CST 2020

interface JTOBTokens {
    int ENDINPUT = 0;
    int AM = 1;
    int ARRAY = 2;
    int ASSIGN = 3;
    int CHARACTER = 4;
    int COLON = 5;
    int DIVIDE = 6;
    int DOUBLEQUOTES = 7;
    int EGTHAN = 8;
    int ELSE = 9;
    int ELTHAN = 10;
    int END = 11;
    int EQUAL = 12;
    int FALSE = 13;
    int FLOOP = 14;
    int GTHAN = 15;
    int ID = 16;
    int IF = 17;
    int INSERT = 18;
    int LBRACKET = 19;
    int LITERAL = 20;
    int LPARENTHESIS = 21;
    int LTHAN = 22;
    int MINUS = 23;
    int MULTIPLY = 24;
    int NEQUAL = 25;
    int PLUS = 26;
    int RBRACKET = 27;
    int RPARENTHESIS = 28;
    int SAY = 29;
    int STRING = 30;
    int TO = 31;
    int TRUE = 32;
    int WHILE = 33;
    int error = 34;
}
