// Output created by jacc on Sun Sep 20 15:30:50 CDT 2020

interface VarCalcTokens {
    int ENDINPUT = 0;
    int ADD = 1;
    int DIV = 2;
    int EQUAL = 3;
    int EXP = 4;
    int ID = 5;
    int LITERAL = 6;
    int LPAREN = 7;
    int MUL = 8;
    int RPAREN = 9;
    int SEMI = 10;
    int SUB = 11;
    int error = 12;
}
